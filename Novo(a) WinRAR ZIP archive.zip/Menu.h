#ifndef MENU_H
#define MENU_H
#include <iostream>
#include <vector>
#include "Cliente.h"
#include <algorithm>
#include <Gerente.h>
#include <string>
#include "Transacoes.h"
using namespace std;
void printMenu(){
    cout << "====== SISTEMA DE GERENCIAMENTO DE BANCO ======\n";
    cout << "1. Cadastrar cliente\n";
    cout << "2. Cadastrar gerente\n";
    cout << "3. Criar transação\n";
    cout << "4. Exibir extrato de um cliente\n";
    cout << "5. Associar gerente a cliente\n";
    cout << "6. Listar clientes\n";
    cout << "7. Listar gerentes\n";
    cout << "8. Salvar dados e sair\n";
    cout << "==================================================" << endl <<
            "Escolha uma opção: ";
}

Gerente* cadastrarGerente(){ 

    cout << "Digite o nome: ";
    string nome;
    cin >> nome;
    cout<< "Digite o login: ";
    string login, senha;

    cin >> login;
    cout << "Digite a senha: ";
    cin >> senha;
    cout << "Digite a data de nascimento(DD:MM:ANO): "; 
    string data;
    cin >> data;

    Gerente* x = new Gerente(login, senha, nome, data, "Gerente");
    return x;


}

void associaGC(){

}




Cliente* cadastrarCliente(){
    cout << "--------Inserção de dados do Cliente---------" << endl;
    cout << "Digite o nome do cliente: "; 
    string nome;
    cin >> nome;
    cout << "Digite a data de nascimento(DD:MM:ANO): "; 
    string data;
    cin >> data;
    cout << "Digite o trabalho: "; 
    string trabalho;
    cin >> trabalho;
    cout << "Digite a remuneração: "; 
    double remuneracao;
    cin>> remuneracao;
    cout << "Digite o tipo de conta: "; 
    string tipoConta;
    cin >> tipoConta;
    double saldo;
    bool temTransacoes;
    while(1){
        cout << "Você quer fazer uma transação para o banco: (sim/nao)";
        string option;
        cin>>option;

        transform(option.begin(), option.end(), option.begin(), ::tolower);
        if(option == "sim"){
            temTransacoes = true;
            cout << "Qual valor de saldo voce quer ter: ";
            cin >> saldo; 
            break;
        }
        else if(option == "nao"){
            temTransacoes = false;
            saldo = 0;
            break;
        }
        cout << "Opção invalida" << endl;

    }

    transform(tipoConta.begin(), tipoConta.end(), tipoConta.begin(), ::tolower);
    double taxaRendimento = 0;
    if(tipoConta == "poupança"){
        if(remuneracao < 5000)
            taxaRendimento = 0.05;
        else if(remuneracao >= 5000){
            taxaRendimento = 0.10;

        }
    }

    cout << "Digite o login: ";
    string login, senha;
    cin >> login;
    cout << "Digite a senha: ";
    cin >> senha;
    Cliente *x = new Cliente(nome, trabalho, login, senha, data, remuneracao, tipoConta, taxaRendimento, saldo);
    
    if(temTransacoes)
        x->setTransacao(criarTransacao(x));

    return x;  
}



Transacoes* criarTransacao(Cliente* client){
    cout << "Inserção de dados da Transações: "<< endl;
    cout << "Tipo: ";
    string tipo, data, horario;
    cin >> tipo;
    transform(tipo.begin(), tipo.end(), tipo.begin(), ::tolower);
    cout << "Data(DD/MM/ANO): ";
    cin >> data;
    cout << "Horário(HH:MM:SS): ";
    cin >> horario;
    cout << "Valor: ";
    double valor;
    cin >> valor;
    
    Transacoes *banco = new Transacoes(tipo, data, horario, valor);
    banco->setClientes(client);
    return banco;
}


Transacoes criarTransacao(Cliente* client1, Cliente* client2){
    cout << "Inserção de dados da Transações: "<< endl;
    cout << "Tipo: ";
    string tipo, data, horario;
    cin >> tipo;
    transform(tipo.begin(), tipo.end(), tipo.begin(), ::tolower);
    cout << "Data(DD/MM/ANO): ";
    cin >> data;
    cout << "Horário(HH:MM:SS): ";
    cin >> horario;
    cout << "Valor: ";
    double valor;
    cin >> valor;
    
    Transacoes entre(tipo, data, horario, valor);
    entre.setClientes(client1);
    entre.setClientes(client2);
    return entre;

}



#endif