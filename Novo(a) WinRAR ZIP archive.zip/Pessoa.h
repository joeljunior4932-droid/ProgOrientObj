#ifndef PESSOA_H
#define PESSOA_H
#include <string>
using namespace std;
class Pessoa{
    private:
        string login;
        string senha;
    
    public:
        string nome;
        string trabalho;
        string dataNasc;
        virtual void exibirDados() const;
        //construtor e destrutor
        Pessoa(string = "", string = "", string = "", string = "", string = "");
        
        virtual ~Pessoa();

        //metodos 
        
        
        void setLogin(const string& login);
        string getLogin() const;
        void setSenha(const string& senha);
        string getSenha() const;
        
        

};

#endif //PESSOA_H